function validarDados() {
    return true;
}
const inputNome = document.getElementById("idNome");
const inputEmail = document.getElementById("idEmail");
const inputMensagem = document.getElementById("idMensagem");
const chkMaiusculas = document.getElementById("chkMaiusculas");
const chkMinusculas = document.getElementById("chkMinusculas");

// Adicionar ouvintes de eventos para os checkboxes
chkMaiusculas.addEventListener("change", function() {
    if (chkMaiusculas.checked) {
        inputNome.value = inputNome.value.toUpperCase();
        inputEmail.value = inputEmail.value.toUpperCase();
        inputMensagem.value = inputMensagem.value.toUpperCase();
    }
});

chkMinusculas.addEventListener("change", function() {
    if (chkMinusculas.checked) {
        inputNome.value = inputNome.value.toLowerCase();
        inputEmail.value = inputEmail.value.toLowerCase();
        inputMensagem.value = inputMensagem.value.toLowerCase();
    }
});
