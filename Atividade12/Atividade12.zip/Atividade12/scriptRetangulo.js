// Definindo a classe Retangulo
class Retangulo {
    constructor(base, altura) {
        this.base = base;
        this.altura = altura;
    }

    // Método para calcular a área do retângulo
    calcularArea() {
        return this.base * this.altura;
    }
}

// Pedindo ao usuário para inserir os valores da base e altura
const base = parseFloat(prompt("Informe o valor da base: "));
const altura = parseFloat(prompt("Informe o valor da altura: "));

// Criando um objeto da classe Retangulo com os valores inseridos
const retangulo = new Retangulo(base, altura);

// Calculando e exibindo a área do retângulo
alert("Cálculo da área: " + retangulo.calcularArea());
