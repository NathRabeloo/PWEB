//ex2
class Conta {
    constructor(nomeCorrentista, banco, numConta, saldo) {
        this._nomeCorrentista = nomeCorrentista;
        this._banco = banco;
        this._numConta = numConta;
        this._saldo = saldo;
    }

    get nomeCorrentista() {
        return this._nomeCorrentista;
    }
    set nomeCorrentista(value) {
        this._nomeCorrentista = value;
    }

    get banco() {
        return this._banco;
    }
    set banco(value) {
        this._banco = value;
    }

    get numConta() {
        return this._numConta;
    }
    set numConta(value) {
        this._numConta = value;
    }

    get saldo() {
        return this._saldo;
    }
    set saldo(value) {
        this._saldo = value;
    }
}

class Corrente extends Conta {
    constructor(nomeCorrentista, banco, numConta, saldo, saldoEspecial) {
        super(nomeCorrentista, banco, numConta, saldo);
        this._saldoEspecial = saldoEspecial;
    }

    get saldoEspecial() {
        return this._saldoEspecial;
    }
    set saldoEspecial(value) {
        this._saldoEspecial = value;
    }
}

class Poupanca extends Conta {
    constructor(nomeCorrentista, banco, numConta, saldo, juros, dataVenc) {
        super(nomeCorrentista, banco, numConta, saldo);
        this._juros = juros;
        this._dataVenc = dataVenc;
    }

    get juros() {
        return this._juros;
    }
    set juros(value) {
        this._juros = value;
    }

    get dataVenc() {
        return this._dataVenc;
    }
    set dataVenc(value) {
        this._dataVenc = value;
    }
}

function inserirDadosConta(mensagem) {
    alert(mensagem);
    const nome = prompt("Informe o nome: ");
    const banco = prompt("Informe o banco: ");
    const numConta = prompt("Informe o número da conta: ");
    const saldo = prompt("Informe o saldo: ");
    return [nome, banco, numConta, saldo];
}

const [nomeCorrente, bancoCorrente, numContaCorrente, saldoCorrente] = inserirDadosConta("Insira os dados referente a conta CORRENTE:");
const saldoEspecialCorrente = prompt("Informe o saldo especial: ");
const objCorrente = new Corrente(nomeCorrente, bancoCorrente, numContaCorrente, saldoCorrente, saldoEspecialCorrente);
alert(`CONTA CORRENTE:\n
    Nome: ${objCorrente.nomeCorrentista}
    Banco: ${objCorrente.banco} 
    Número da conta: ${objCorrente.numConta}
    Saldo: ${objCorrente.saldo} 
    Saldo Especial: ${objCorrente.saldoEspecial}
`);

const [nomePoupanca, bancoPoupanca, numContaPoupanca, saldoPoupanca] = inserirDadosConta("Insira os dados referente a conta POUPANÇA:");
const jurosPoupanca = prompt("Informe a taxa de juros: ");
const dataVencPoupanca = prompt("Informe a data de vencimento: ");
const objPoupanca = new Poupanca(nomePoupanca, bancoPoupanca, numContaPoupanca, saldoPoupanca, jurosPoupanca, dataVencPoupanca);
alert(`CONTA POUPANÇA:\n
    Nome: ${objPoupanca.nomeCorrentista}
    Banco: ${objPoupanca.banco} 
    Número da conta: ${objPoupanca.numConta}
    Saldo: ${objPoupanca.saldo} 
    Juros: ${objPoupanca.juros}
    Data de vencimento: ${objPoupanca.dataVenc}
`);
