
function encontrarMaior() {
    const num1 = parseInt(prompt("Digite o primeiro número:"));
    const num2 = parseInt(prompt("Digite o segundo número:"));
    const num3 = parseInt(prompt("Digite o terceiro número:"));

    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        alert("Por favor, insira números válidos.");
        encontrarMaior();
        return;
    }
    const maior = Math.max(num1, num2, num3);
    alert("O maior número é: " + maior);
}

function ordenarCrescente() {
    const num1 = parseInt(prompt("Digite o primeiro número:"));
    const num2 = parseInt(prompt("Digite o segundo número:"));
    const num3 = parseInt(prompt("Digite o terceiro número:"));
    if (isNaN(num1) || isNaN(num2) || isNaN(num3)) {
        alert("Por favor, insira números válidos.");
        ordenarCrescente();
        return;
    }
    const sortedNumbers = [num1, num2, num3].sort((a, b) => a - b);
    alert("Em ordem crescente: " + sortedNumbers.join(", "));
}

function verificarPalindromo() {
    const texto = prompt("Digite uma palavra");
    const textoFormatado = texto.replace(/\s/g, '').toUpperCase();
    const reverso = textoFormatado.split('').reverse().join('');
    if (textoFormatado === reverso) {
        alert("Sim, é um palíndromo: " + texto);
    } else {
        alert("Não é um palíndromo");
    }
}

function identificarTriangulo() {
    const a = parseFloat(prompt("Digite o primeiro valor:"));
    const b = parseFloat(prompt("Digite o segundo valor:"));
    const c = parseFloat(prompt("Digite o terceiro valor:"));
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        alert("Por favor, insira números válidos.");
        identificarTriangulo();
        return;
    }
    if (a + b > c && a + c > b && b + c > a) {
        if (a === b && b === c) {
            alert('Equilátero'); // Triângulo com lados iguais 
        } else if (a === b || b === c || a === c) {
            alert('Isósceles'); // Triângulo com dois lados iguais
        } else {
            alert('Escaleno'); // Triângulo com lados diferentes
        }
    } else {
        alert('Não forma um triângulo');
    }
}
