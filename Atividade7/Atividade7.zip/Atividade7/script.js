function jogar(escolhaDoJogador) {
    const opcoes = ['pedra', 'papel', 'tesoura'];
    const escolhaDoComputador = opcoes[Math.floor(Math.random() * opcoes.length)];
    alert('Aguarde, o Computador está escolhendo...')
    // Lógica para determinar o vencedor
    if (escolhaDoJogador === escolhaDoComputador) {
        alert('Empate! Ambos escolheram ' + escolhaDoJogador + '.');
    } else if (
        (escolhaDoJogador === 'pedra' && escolhaDoComputador === 'tesoura') ||
        (escolhaDoJogador === 'papel' && escolhaDoComputador === 'pedra') ||
        (escolhaDoJogador === 'tesoura' && escolhaDoComputador === 'papel')
    ) {
        alert('Você ganhou! ' + escolhaDoJogador + ' vence ' + escolhaDoComputador + '.');
    } else {
        alert('Você perdeu! ' + escolhaDoComputador + ' vence ' + escolhaDoJogador + '.');
    }
}