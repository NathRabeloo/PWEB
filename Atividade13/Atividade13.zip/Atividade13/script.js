const janela = document.getElementById('janela');

janela.addEventListener('mouseover', function() {
  this.style.backgroundImage = "url('img/janelaAberta.png')";
});

janela.addEventListener('mouseout', function() {
  this.style.backgroundImage = "url('img/janelaFechada.png')";
});

janela.addEventListener('click', function() {
  this.style.backgroundImage = "url('img/janelaQuebrada.png')";
  console.log('clicou');
});
