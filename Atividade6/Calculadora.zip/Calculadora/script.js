// Função para realizar as operações matemáticas
function realizarOperacoes() {
    var primeiroNumero = prompt("Digite o primeiro número:");


    if (primeiroNumero === null || primeiroNumero === "") {
        alert("Você não inseriu um número válido para o primeiro número.");
        return;
    }

    // Pedir ao usuário para inserir o segundo número
    var segundoNumero = prompt("Digite o segundo número:");

    if (segundoNumero === null || segundoNumero === "") {
        alert("Você não inseriu um número válido para o segundo número.");
        return;
    }

    primeiroNumero = parseFloat(primeiroNumero);
    segundoNumero = parseFloat(segundoNumero);

    if (isNaN(primeiroNumero) || isNaN(segundoNumero)) {
        alert("Pelo menos um dos números inseridos não é válido.");
        return;
    }

    var soma = primeiroNumero + segundoNumero;
    var subtracao = primeiroNumero - segundoNumero;
    var produto = primeiroNumero * segundoNumero;
    var divisao = primeiroNumero / segundoNumero;
    var resto = primeiroNumero % segundoNumero;

    alert("Soma: " + soma.toFixed(2) + "\n" +
          "Subtração: " + subtracao.toFixed(2) + "\n" +
          "Produto: " + produto.toFixed(2) + "\n" +
          "Divisão: " + divisao.toFixed(2) + "\n" +
          "Resto: " + resto.toFixed(2));
}

realizarOperacoes();
