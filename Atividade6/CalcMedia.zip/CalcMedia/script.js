// Função para calcular a média das notas
function calcularMedia() {
    var nomeAluno = prompt("Digite o nome do aluno:");

    if (nomeAluno === null || nomeAluno === "") {
        alert("Você não inseriu um nome de aluno válido.");
        return;
    }

    var nota1 = prompt("Digite a primeira nota:");
    var nota2 = prompt("Digite a segunda nota:");
    var nota3 = prompt("Digite a terceira nota:");

    if (nota1 === null || nota2 === null || nota3 === null) {
        alert("Você cancelou a inserção das notas.");
        return;
    }

    nota1 = parseFloat(nota1);
    nota2 = parseFloat(nota2);
    nota3 = parseFloat(nota3);

    if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
        alert("Alguma das notas inseridas não é válida.");
        return;
    }

    var media = (nota1 + nota2 + nota3) / 3;

    alert("A média do aluno " + nomeAluno + " é: " + media.toFixed(2));
}

calcularMedia();
